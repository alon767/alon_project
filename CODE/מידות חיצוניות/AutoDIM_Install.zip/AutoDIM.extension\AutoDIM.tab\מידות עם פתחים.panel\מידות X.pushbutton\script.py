# -*- coding: utf-8 -*-
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import run_axis_dim_openings
run_axis_dim_openings("X")
