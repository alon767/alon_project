# -*- coding: utf-8 -*-
"""מידות פנימיות X"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import run_axis_dim
run_axis_dim("X")
