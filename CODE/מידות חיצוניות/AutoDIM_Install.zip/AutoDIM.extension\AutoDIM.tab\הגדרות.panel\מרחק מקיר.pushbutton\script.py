# -*- coding: utf-8 -*-
"""הגדרת מרחק קו מידה מהקיר (ס"מ)"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import load_settings, save_settings
from pyrevit import forms, script

settings = load_settings()
current  = settings.get("wall_dim_offset", 100)

val = forms.ask_for_string(
    prompt="הכנס מרחק קו מידה מהקיר (ס\"מ):",
    title="מרחק מקיר",
    default=str(current)
)
if val is not None:
    val = val.strip()
    try:
        num = int(round(float(val)))
        if num <= 0:
            forms.alert("יש להכניס מספר חיובי.", title="שגיאה")
        else:
            settings["wall_dim_offset"] = num
            save_settings(settings)
            try:
                btn = script.get_button()
                if btn:
                    btn.set_title(u"מרחק: {} ס\"מ".format(num))
            except:
                pass
    except ValueError:
        forms.alert("ערך לא תקין — יש להכניס מספר שלם.", title="שגיאה")
