# -*- coding: utf-8 -*-
"""בחירת מפלסים — אם נבחרות כאן תכניות, כפתורי מידות חיצוניות ירוצו אוטומטית על כולן"""
import sys, os, traceback
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import load_settings, save_settings, get_all_floor_plan_views
from pyrevit import forms, script, revit

try:
    doc = revit.doc
    settings = load_settings()

    views = get_all_floor_plan_views(doc)
    if not views:
        forms.alert(u"לא נמצאו תכניות קומה בפרויקט.", title=u"שגיאה")
        script.exit()

    saved_ids = set(settings.get("reference_view_ids", []))
    items = [forms.TemplateListItem(v, checked=(v.Id.IntegerValue in saved_ids), name_attr="Name")
             for v in views]

    picked = forms.SelectFromList.show(
        items, multiselect=True,
        button_name=u"אישור",
        title=u"בחירת מפלסים",
        prompt=u"סמן תכניות קומה — מידות חיצוניות ירוצו אוטומטית על כולן (ריק = רק על התצוגה הפעילה)."
    )

    if picked is None:
        forms.alert(u"לא בוצע שינוי (הבחירה בוטלה — נסגר בלי ללחוץ אישור).", title=u"בחירת מפלסים")
        script.exit()

    ids   = [v.Id.IntegerValue for v in picked]
    names = [v.Name for v in picked]
    settings["reference_view_ids"] = ids
    save_settings(settings)

    # אימות שהשמירה אכן קרתה בפועל בקובץ (לא רק בזיכרון)
    check = load_settings().get("reference_view_ids", [])
    if sorted(check) != sorted(ids):
        forms.alert(u"שגיאה: השמירה לא הצליחה בפועל בקובץ ההגדרות.",
                    title=u"בחירת מפלסים — שגיאה")
        script.exit()

    try:
        btn = script.get_button()
        if btn:
            btn.set_title(u"בחירת מפלסים: {}".format(len(ids)) if ids else u"בחירת מפלסים")
    except:
        pass

    if ids:
        forms.alert(u"נשמרו {} תכניות:\n{}".format(len(ids), u"\n".join(names)),
                    title=u"בחירת מפלסים")
    else:
        forms.alert(u"לא נבחרה אף תכנית — מידות חיצוניות יופעלו רק על התצוגה הפעילה.",
                    title=u"בחירת מפלסים")

except Exception as ex:
    forms.alert(u"שגיאה:\n{}\n\n{}".format(str(ex), traceback.format_exc()),
                title=u"בחירת מפלסים — שגיאה קריטית")
