# -*- coding: utf-8 -*-
"""בחירת סגנון קו מידה"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import load_settings, save_settings, get_dim_style, is_linear_dim_style
from Autodesk.Revit.DB import *
from pyrevit import revit, forms

doc = revit.doc

styles = []
for dt in FilteredElementCollector(doc).OfClass(DimensionType):
    if not is_linear_dim_style(dt):
        continue
    try:
        n = dt.get_Parameter(BuiltInParameter.ALL_MODEL_TYPE_NAME).AsString()
        if n:
            styles.append(n)
    except:
        pass

styles = sorted(set(styles))
if not styles:
    forms.alert("לא נמצאו סגנונות מידה ליניאריים בקובץ.", title="סגנון מידה")
else:
    settings = load_settings()
    current = settings.get("dim_style", "")
    selected = forms.SelectFromList.show(
        styles,
        title="בחר סגנון קו מידה",
        prompt="סגנון נוכחי: {}".format(current or "ברירת מחדל"),
        multiselect=False
    )
    if selected:
        settings["dim_style"] = selected
        save_settings(settings)
        forms.alert("סגנון מידה עודכן ל: {}".format(selected), title="הגדרות")
