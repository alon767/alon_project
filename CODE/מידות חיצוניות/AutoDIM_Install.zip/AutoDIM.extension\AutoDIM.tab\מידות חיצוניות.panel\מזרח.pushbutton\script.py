# -*- coding: utf-8 -*-
"""מידות חזית מזרח"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import run_facade
run_facade("מזרח", is_horizontal=False, perp_x=1, perp_y=0)
