# -*- coding: utf-8 -*-
"""אתחול אייקון Multiple לפי המצב השמור"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import load_settings
from pyrevit import script

btn_dir = os.path.dirname(__file__)
try:
    this_button = script.get_button()
    if this_button:
        settings = load_settings()
        icon = os.path.join(btn_dir, 'on.png' if settings.get('multiple', False) else 'icon.png')
        this_button.set_icon(icon)
except:
    pass
