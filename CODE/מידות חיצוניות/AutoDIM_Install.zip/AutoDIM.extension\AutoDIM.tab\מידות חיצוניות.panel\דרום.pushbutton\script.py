# -*- coding: utf-8 -*-
"""מידות חזית דרום"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import run_facade
run_facade("דרום", is_horizontal=True, perp_x=0, perp_y=-1)
