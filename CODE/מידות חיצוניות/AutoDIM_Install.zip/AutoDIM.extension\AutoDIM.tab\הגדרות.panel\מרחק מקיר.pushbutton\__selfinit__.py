# -*- coding: utf-8 -*-
"""אתחול שם כפתור מרחק מקיר לפי הערך השמור"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import load_settings
from pyrevit import script

try:
    btn = script.get_button()
    if btn:
        val = load_settings().get("wall_dim_offset", 100)
        btn.set_title(u"מרחק: {} ס\"מ".format(val))
except:
    pass
