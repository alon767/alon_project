# -*- coding: utf-8 -*-
"""מצב Multiple — מידות חוזרות עד Esc"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import load_settings, save_settings
from pyrevit import script

settings = load_settings()
new_val  = not settings.get('multiple', False)
settings['multiple'] = new_val
save_settings(settings)

btn_dir = os.path.dirname(__file__)
icon    = os.path.join(btn_dir, 'on.png' if new_val else 'icon.png')
try:
    this_button = script.get_button()
    if this_button:
        this_button.set_icon(icon)
except:
    pass
