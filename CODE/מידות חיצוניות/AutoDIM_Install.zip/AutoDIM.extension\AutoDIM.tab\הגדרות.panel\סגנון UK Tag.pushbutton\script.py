# -*- coding: utf-8 -*-
"""בחירת סגנון תגית UK"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import load_settings, save_settings
from Autodesk.Revit.DB import *
from pyrevit import revit, forms

doc = revit.doc

tags = []
for ft in FilteredElementCollector(doc).OfClass(FamilySymbol):
    try:
        cat = ft.Category
        if cat and cat.Id.IntegerValue == int(BuiltInCategory.OST_WindowTags):
            n = ft.get_Parameter(BuiltInParameter.ALL_MODEL_TYPE_NAME).AsString()
            if n:
                tags.append(n)
    except:
        pass

tags = sorted(set(tags))
if not tags:
    forms.alert("לא נמצאו סגנונות תגית חלון בקובץ.", title="סגנון UK Tag")
else:
    settings = load_settings()
    current = settings.get("uk_tag_style", "")
    selected = forms.SelectFromList.show(
        tags,
        title="בחר סגנון תגית UK",
        prompt="סגנון נוכחי: {}".format(current or "ברירת מחדל"),
        multiselect=False
    )
    if selected:
        settings["uk_tag_style"] = selected
        save_settings(settings)
        forms.alert("סגנון UK Tag עודכן ל: {}".format(selected), title="הגדרות")
