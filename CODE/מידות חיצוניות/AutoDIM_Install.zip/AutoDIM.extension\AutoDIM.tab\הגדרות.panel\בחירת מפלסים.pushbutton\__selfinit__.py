# -*- coding: utf-8 -*-
"""אתחול שם כפתור בחירת מפלסים לפי הבחירה השמורה"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import load_settings
from pyrevit import script

try:
    btn = script.get_button()
    if btn:
        ids = load_settings().get("reference_view_ids", [])
        if ids:
            btn.set_title(u"בחירת מפלסים: {}".format(len(ids)))
        else:
            btn.set_title(u"בחירת מפלסים")
except:
    pass
