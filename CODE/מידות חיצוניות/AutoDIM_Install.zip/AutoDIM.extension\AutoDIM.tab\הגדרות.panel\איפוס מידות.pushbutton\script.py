# -*- coding: utf-8 -*-
"""איפוס מידות — מוחק מידות/תגיות בטווח שנבחר.

שני מצבי זיהוי:
- "לפי סגנון AutoDIM" (ברירת מחדל, בטוח): רק Dimension/IndependentTag
  שהטיפוס שלהם תואם לסגנון המוגדר כרגע בהגדרות (dim_style / uk_tag_style /
  cw_tag_style). לא תיוג ישיר על כל אלמנט — היוריסטיקה בלבד.
- "מחיקה מלאה" (מסוכן יותר): כל Dimension/IndependentTag בתצוגה בלי שום
  סינון — כולל מידות/תגיות שהמשתמש יצר ידנית. לשימוש כשיש חשד לאלמנטים
  ישנים שנוצרו בסגנון אחר (מסבבי בדיקה קודמים) ולכן לא נתפסים במצב הרגיל.

כרגע מוחק הכול יחד (בלי פיצול לקטגוריות מידות חיצוניות/פנימיות/עם
פתחים) — זה יגיע בהמשך.
"""
import sys, os, traceback
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import (get_autodim_created_element_ids, get_all_dim_and_tag_ids,
                        get_autodim_reference_plane_ids, get_reference_views, load_settings)
from pyrevit import forms, script, revit
from Autodesk.Revit.DB import ElementId
from System.Collections.Generic import List

try:
    doc   = revit.doc
    uidoc = revit.uidoc

    settings = load_settings()
    has_selected_views = bool(settings.get("reference_view_ids"))

    scope_options = [u"התצוגה הפעילה בלבד"]
    if has_selected_views:
        scope_options.append(u"כל התכניות שנבחרו ב'בחירת מפלסים'")

    scope_choice = forms.CommandSwitchWindow.show(
        scope_options, message=u"על אילו תכניות לבצע איפוס מידות?")
    if not scope_choice:
        script.exit()

    if scope_choice == scope_options[0]:
        target_views = [uidoc.ActiveView]
    else:
        target_views = get_reference_views(doc, uidoc)

    mode_options = [u"לפי סגנון AutoDIM (בטוח)",
                    u"מחיקה מלאה — כל מידה/תגית בתצוגה (מסוכן, כולל ידניות)"]
    mode_choice = forms.CommandSwitchWindow.show(
        mode_options, message=u"איך לזהות מה למחוק?")
    if not mode_choice:
        script.exit()

    nuclear = (mode_choice == mode_options[1])
    if nuclear:
        if not forms.alert(
                u"מצב 'מחיקה מלאה' ימחק כל מידה ותגית בתצוגה שנבחרה — "
                u"כולל כאלה שיצרת ידנית, לא רק מה ש-AutoDIM יצר. להמשיך?",
                title=u"איפוס מידות — אזהרה", ok=False, yes=True, no=True):
            script.exit()

    all_ids = []
    per_view_counts = []
    for v in target_views:
        ids = get_all_dim_and_tag_ids(doc, v) if nuclear else get_autodim_created_element_ids(doc, v)
        if ids:
            per_view_counts.append(u"{}: {}".format(v.Name, len(ids)))
        all_ids += ids

    # Reference Plane-ים סינתטיים (גיבוי אחרון לגבולות קיר מסך/קיר) —
    # אלמנט גלובלי במסמך, לא תלוי-תצוגה, נאסף פעם אחת בלי קשר ל-scope.
    # חשוב לכלול תמיד: הם נשמרים/נמצאים-מחדש לפי שם, אז ישן שנוצר בגובה
    # שגוי בגרסה קודמת של הקוד ימשיך להימצא ולשמש שוב אם לא ננקה אותו.
    rp_ids = get_autodim_reference_plane_ids(doc)
    if rp_ids:
        per_view_counts.append(u"Reference Planes (כל המסמך): {}".format(len(rp_ids)))
    all_ids += rp_ids

    if not all_ids:
        forms.alert(u"לא נמצאו מידות/תגיות למחיקה בטווח שנבחר.",
                    title=u"איפוס מידות")
        script.exit()

    confirm = forms.alert(
        u"נמצאו {} אלמנטים למחיקה:\n{}\n\nלמחוק את כולם?".format(
            len(all_ids), u"\n".join(per_view_counts)),
        title=u"איפוס מידות — אישור מחיקה",
        ok=False, yes=True, no=True
    )
    if not confirm:
        script.exit()

    with revit.Transaction(u"AutoDIM — איפוס מידות"):
        doc.Delete(List[ElementId](all_ids))

    forms.alert(u"נמחקו {} אלמנטים.".format(len(all_ids)), title=u"איפוס מידות")

except Exception as ex:
    forms.alert(u"שגיאה:\n{}\n\n{}".format(str(ex), traceback.format_exc()),
                title=u"איפוס מידות — שגיאה קריטית")
