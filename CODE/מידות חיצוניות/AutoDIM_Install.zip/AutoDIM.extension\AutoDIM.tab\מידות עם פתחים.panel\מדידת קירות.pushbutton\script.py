# -*- coding: utf-8 -*-
"""מדידת קירות — לחץ על קיר, מקבל מידה עם פתחים במרחק 100 ס"מ"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from dim_utils import run_wall_dim
run_wall_dim()
