# -*- coding: utf-8 -*-
"""כלי תחזוקה: איפוס מספור (Resh_*_Number) - בוחרים קטגוריה (נגרות/מסגרות/אלומיניום), עם אישור לפני ביצוע"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from alutag_utils import run_reset_numbering
run_reset_numbering()
