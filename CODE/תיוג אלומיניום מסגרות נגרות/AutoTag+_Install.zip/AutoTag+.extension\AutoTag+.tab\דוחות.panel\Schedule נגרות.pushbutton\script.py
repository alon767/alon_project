# -*- coding: utf-8 -*-
"""יצירת Schedule אוטומטי לנגרות (דלתות עץ)"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from alutag_schedule import create_carpentry_schedule
create_carpentry_schedule()
