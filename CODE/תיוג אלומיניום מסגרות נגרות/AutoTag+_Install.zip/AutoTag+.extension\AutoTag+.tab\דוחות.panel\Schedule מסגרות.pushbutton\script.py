# -*- coding: utf-8 -*-
"""יצירת Schedule אוטומטי למסגרות (דלתות פלדה + מסגרת/צינורות חלונות Shield)"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from alutag_schedule import create_frames_schedule
create_frames_schedule()
