# -*- coding: utf-8 -*-
"""יצירת Schedule אוטומטי לאלומיניום (חלונות + קירות מסך)"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from alutag_schedule import create_aluminum_schedule
create_aluminum_schedule()
