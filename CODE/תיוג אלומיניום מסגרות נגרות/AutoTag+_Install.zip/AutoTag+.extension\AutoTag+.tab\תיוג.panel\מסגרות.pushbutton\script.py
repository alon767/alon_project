# -*- coding: utf-8 -*-
"""תיוג אוטומטי — מסגרות (דלתות פלדה + מסגרת/צינורות בחלונות מורכבים + צינורות בדלתות מורכבות)"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from alutag_utils import run_tag_doors, run_tag_frames_in_windows, run_tag_pipes_in_doors
run_tag_doors(is_carpentry=False)
run_tag_frames_in_windows()
run_tag_pipes_in_doors()
