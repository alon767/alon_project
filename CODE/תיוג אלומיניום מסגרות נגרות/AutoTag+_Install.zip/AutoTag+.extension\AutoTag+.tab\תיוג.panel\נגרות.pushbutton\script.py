# -*- coding: utf-8 -*-
"""תיוג אוטומטי — נגרות (דלתות עץ)"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from alutag_utils import run_tag_doors
run_tag_doors(is_carpentry=True)
