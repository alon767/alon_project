# -*- coding: utf-8 -*-
"""תיוג אוטומטי — אלומיניום (חלונות + קירות מסך)"""
import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'lib'))
from alutag_utils import run_tag_aluminum
run_tag_aluminum()
